
let barrm = document.getElementById("barrm")
function barmenu() {
  barrm.classList.toggle("open")
} 



  
  function styl(color) {
    
    document.getElementById("codo").style.background = color;
    
    localStorage.setItem('background', color);
    
  }
    
    window.addEventListener('load', function() {
    const storedColor = localStorage.getItem('background');
    if (storedColor) {
          document.getElementById("codo").style.background 
= storedColor;
    }
});
    
    
   let rburger = document.getElementById("rburger")
   
   
   function rlbur(){
     rburger.classList.toggle("open")
   }
    
    